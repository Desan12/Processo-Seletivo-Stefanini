package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class home extends pageObject {
@FindBy(id = "name")
private WebElement nome;

@FindBy (id = "email")
private WebElement email;

@FindBy (id = "password")
private WebElement senha;

public home(WebDriver driver) {
	super(driver);
	
}



}
