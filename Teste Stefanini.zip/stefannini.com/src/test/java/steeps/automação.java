package steeps;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.pt.Dado;
import cucumber.api.java.pt.Entao;
import cucumber.api.java.pt.Então;
import cucumber.api.java.pt.Quando;
import io.github.bonigarcia.wdm.WebDriverManager;
import page.home;

public class automação {

	WebDriver driver;

	home Home;

	@Before
	public void Iniciar() {
		// driver.get("http://prova.stefanini-jgr.com.br/teste/qa/");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		Home = new home(driver);

	}

	@After
	public void Finalizar() {
//		driver.quit();
	}

	@Test
	public void abrirPagina() {
		driver.get("http://prova.stefanini-jgr.com.br/teste/qa/");
	}

	@Dado("^que estou na pagina de cadastro de usuários da Stefanini$")
	public void que_estou_na_pagina_de_cadastro_de_usuários_da_Stefanini() {
		driver.get("http://prova.stefanini-jgr.com.br/teste/qa/");

	}

	@Quando("^insiro meus dados \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void insiro_meus_dados(String nome, String email, String senha) {
		driver.findElement(By.id("name")).sendKeys(Keys.CLEAR);
		driver.findElement(By.id("name")).sendKeys(nome);
		driver.findElement(By.id("email")).sendKeys(Keys.CLEAR);
		driver.findElement(By.id("email")).sendKeys(email);
		driver.findElement(By.id("password")).sendKeys(Keys.CLEAR);
		driver.findElement(By.id("password")).sendKeys(senha);

	}

	@Quando("^clico no botão Cadastrar$")
	public void clico_no_botão_Cadastrar() {
		driver.findElement(By.id("register")).sendKeys(Keys.ENTER);
	}

	@Entao("^o sistema deve exibir uma \"([^\"]*)\" de erro$")
	public void o_sistema_deve_exibir_uma_de_erro(String msgmEsperada) {
		assertEquals(msgmEsperada, driver.findElement(By.cssSelector("p.error")).getText());
	}

//
	@Quando("^Insiro meus dados <nome>, <email>, <senha>$")
	public void insiro_meus_dados_nome_email_senha() {
		driver.findElement(By.id("name")).sendKeys("Gabriel Bonfim");
		driver.findElement(By.id("email")).sendKeys("g.bonfim@email.com");
		driver.findElement(By.id("password")).sendKeys("12345678");
		driver.findElement(By.id("register")).sendKeys(Keys.ENTER);
		driver.findElement(By.id("name")).sendKeys("Luana Santos");
		driver.findElement(By.id("email")).sendKeys("l.santos@email.com");
		driver.findElement(By.id("password")).sendKeys("87654321");
		driver.findElement(By.id("register")).sendKeys(Keys.ENTER);
	}

	@Entao("^sou Cadastrado <msgm>$")
	public void sou_Cadastrado_msgm() throws Throwable {
		String msgmEsperada = "Usuários cadastrados";
		assertEquals(msgmEsperada, driver.findElement(By.cssSelector("h2.table-title")).getText());
	}

	@Quando("^clico no no botão$")
	public void clico_no_no_botão() {
		driver.findElement(By.id("removeUser1")).click();
	}

	@Então("^sou excluido$")
	public void sou_excluido() {
		

	}

}
